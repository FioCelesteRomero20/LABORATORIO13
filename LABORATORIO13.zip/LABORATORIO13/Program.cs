﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LABORATORIO13
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int opcion = Pantallas.pantallaPrincipal();
            
            do
            {
                
                Console.Clear();
                switch (opcion)
                {
                    case 1:
                        Pantallas.realizarEncuesta();
                        Console.ReadKey();
                        break;
                    case 2:
                        opcion = Pantallas.verDatosRegistrados();
                        break;
                    case 3:
                        opcion = Pantallas.eliminarUnDato();
                        break;
                    case 4:
                        opcion = Pantallas.OrdenarDatosDeMenorAMayor();
                        break;
                   
                }
                opcion = Pantallas.pantallaPrincipal();
            } while (opcion != 5);

        }
    }
}
